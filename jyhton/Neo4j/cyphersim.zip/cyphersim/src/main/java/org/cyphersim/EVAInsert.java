package org.cyphersim;

public class EVAInsert {
	public Entity modified;
	public String EVAname;
	
	public EVAInsert(Entity m, Entity i, String e) {
		modified = m;
		EVAname = e;
	}
}
