package org.cyphersim;

public class LabelledNode {
	public String id;
	public String label;
	
	public LabelledNode(String i, String l) {
		id = i;
		label = l;
	}
}
