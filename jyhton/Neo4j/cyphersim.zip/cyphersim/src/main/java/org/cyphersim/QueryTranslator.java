package org.cyphersim;

public interface QueryTranslator {
	String translate(String query);
}
