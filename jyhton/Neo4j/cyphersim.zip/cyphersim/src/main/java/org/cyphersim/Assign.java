package org.cyphersim;

public class Assign {
	public String property;
	public String value;
	
	public Assign(String p, String v) {
		property = p;
		value = v;
	}
}
